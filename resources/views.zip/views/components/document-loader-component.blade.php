<div class="document-loader fixed z-[99] h-screen w-full flex items-center justify-center bg-white/50 top-0 left-0">
 <img src="https://cdn.pixabay.com/animation/2022/07/29/03/42/03-42-11-849_512.gif" alt="" class="h-12 w-12">
</div>
