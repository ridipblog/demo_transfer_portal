<footer class="mt-auto">
    <div class="max-w-7xl mx-auto flex justify-center items-center py-4 text-gray-500 text-xs">
        @lang('home.footer')
    </div>
</footer>
