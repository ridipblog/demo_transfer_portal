$(document).on('click','#pop-close-btn',function(){
    $('.main-pop-card-div').addClass('hidden');
})
