window.addEventListener('load', function () {
  // Hide the loader after the window is fully loaded
  $('body').removeClass('overflow-hidden')
});
